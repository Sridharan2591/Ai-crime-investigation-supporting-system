from flask import Flask, render_template, request, jsonify
import os
import threading
import torch
from datetime import datetime

# --- Import from 'modules' folder ---
from modules.image_tampering import predict_image_tampering
from modules.audio_analysis import analyze_audio
from modules.chatbot import get_chatbot_response
from modules.face_emotion_live import start_webcam_detection
from modules.inference import predict_vedio
from modules.model import ImprovedEfficientViT

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
os.makedirs('uploads', exist_ok=True)

# Pre-load the heavy Video Model globally
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
video_model = ImprovedEfficientViT()
MODEL_PATH_V = os.path.join(os.path.dirname(__file__), "models", "video_model.pth")

if os.path.exists(MODEL_PATH_V):
    video_model.load_state_dict(torch.load(MODEL_PATH_V, map_location=device))
    video_model.to(device).eval()
    print("✅ Video Forensic Model Loaded")

@app.route('/')
def home():
    # Pass current date/time to the template
    now = datetime.now()
    dt_string = now.strftime("%A, %B %d, %Y")
    return render_template('index.html', current_date=dt_string)

@app.route('/analyze_image', methods=['POST'])
def img_route():
    file = request.files['file']
    path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
    file.save(path)
    result, conf = predict_image_tampering(path)
    return jsonify({"result": result, "confidence": conf})

@app.route('/analyze_video', methods=['POST'])
def video_route():
    file = request.files['file']
    path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
    file.save(path)
    result = predict_vedio(path, video_model)
    return jsonify(result)

@app.route('/start_live_face')
def live_face():
    # Use threading to prevent the website from freezing
    threading.Thread(target=start_webcam_detection, daemon=True).start()
    return jsonify({"status": "Live Analysis Started"})

@app.route('/chat', methods=['POST'])
def chat_route():
    msg = request.json.get("message")
    return jsonify(get_chatbot_response(msg))

if __name__ == '__main__':
    # use_reloader=False prevents double-loading AI models (Fixes SystemExit)
    app.run(debug=True, port=5050, use_reloader=False)