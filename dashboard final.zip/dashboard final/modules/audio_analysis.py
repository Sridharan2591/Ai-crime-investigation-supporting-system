import numpy as np
import librosa
import tensorflow as tf
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

def analyze_audio(file_path):
    try:
        # Load models locally to save memory
        tamper_path = os.path.join(BASE_DIR, "..", "models", "audio_tamper_model.h5")
        t_model = tf.keras.models.load_model(tamper_path)
        
        audio, sr = librosa.load(file_path, sr=22050, mono=True)
        audio = audio / (np.max(np.abs(audio)) + 1e-7)
        
        mfcc = librosa.feature.mfcc(y=audio, sr=sr, n_mfcc=40).T
        if mfcc.shape[0] < 174:
            mfcc = np.pad(mfcc, ((0, 174 - mfcc.shape[0]), (0, 0)))
        else:
            mfcc = mfcc[:174]
            
        pred = t_model.predict(mfcc[np.newaxis, ..., np.newaxis], verbose=0)[0][0]
        return ("Tampered" if pred > 0.5 else "Original", "Success")
    except Exception as e:
        return "Error", str(e)