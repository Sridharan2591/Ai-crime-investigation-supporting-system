import requests

def get_chatbot_response(message):
    try:
        res = requests.post(
            "http://localhost:11434/api/generate",
            json={"model": "llama3", "prompt": f"Crime context: {message}", "stream": False},
            timeout=10
        )
        return {"response": res.json().get("response", "No response")}
    except:
        return {"response": "Ensure Ollama (Llama3) is running locally."}