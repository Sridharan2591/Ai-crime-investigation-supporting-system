import os
import cv2
import torch
from mtcnn import MTCNN
from torchvision import transforms
from .model import ImprovedEfficientViT # Relative import

def predict_vedio(video_path, model_video):
    detector = MTCNN()
    cap = cv2.VideoCapture(video_path)
    # Simple extraction of 10 frames to prevent memory crash
    frames = []
    for _ in range(10):
        ret, frame = cap.read()
        if not ret: break
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        res = detector.detect_faces(rgb)
        if res:
            x, y, w, h = res[0]['box']
            frames.append(cv2.resize(rgb[max(0,y):y+h, max(0,x):x+w], (224, 224)))
    cap.release()

    if not frames: return {"result": "No face found", "confidence": 0}
    
    transform = transforms.Compose([transforms.ToPILImage(), transforms.ToTensor()])
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    results = []
    for f in frames:
        with torch.no_grad():
            inp = transform(f).unsqueeze(0).to(device)
            results.append(torch.sigmoid(model_video(inp)).item())
    
    avg = sum(results)/len(results)
    return {"result": "Fake" if avg > 0.5 else "Real", "confidence": round(avg*100, 2)}